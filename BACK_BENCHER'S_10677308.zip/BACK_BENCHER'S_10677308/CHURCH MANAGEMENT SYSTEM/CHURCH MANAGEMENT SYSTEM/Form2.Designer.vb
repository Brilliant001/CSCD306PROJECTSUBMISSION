﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.FIRSTNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LASTNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOBDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GENDERDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMAILDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MARITALSTATUSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MEMBERINFOBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet = New CHURCH_MANAGEMENT_SYSTEM.CHURCH_MANAGEMENT_SYSTEMDataSet()
        Me.MEMBER_INFOTableAdapter = New CHURCH_MANAGEMENT_SYSTEM.CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.MEMBER_INFOTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FIRSTNAMEDataGridViewTextBoxColumn, Me.LASTNAMEDataGridViewTextBoxColumn, Me.DOBDataGridViewTextBoxColumn, Me.GENDERDataGridViewTextBoxColumn, Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn, Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn, Me.TELEPHONENUMBERDataGridViewTextBoxColumn, Me.EMAILDataGridViewTextBoxColumn, Me.MARITALSTATUSDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MEMBERINFOBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(20, 17)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(400, 208)
        Me.DataGridView1.TabIndex = 0
        '
        'FIRSTNAMEDataGridViewTextBoxColumn
        '
        Me.FIRSTNAMEDataGridViewTextBoxColumn.DataPropertyName = "FIRST NAME]"
        Me.FIRSTNAMEDataGridViewTextBoxColumn.HeaderText = "FIRST NAME]"
        Me.FIRSTNAMEDataGridViewTextBoxColumn.Name = "FIRSTNAMEDataGridViewTextBoxColumn"
        '
        'LASTNAMEDataGridViewTextBoxColumn
        '
        Me.LASTNAMEDataGridViewTextBoxColumn.DataPropertyName = "LAST NAME"
        Me.LASTNAMEDataGridViewTextBoxColumn.HeaderText = "LAST NAME"
        Me.LASTNAMEDataGridViewTextBoxColumn.Name = "LASTNAMEDataGridViewTextBoxColumn"
        '
        'DOBDataGridViewTextBoxColumn
        '
        Me.DOBDataGridViewTextBoxColumn.DataPropertyName = "DOB"
        Me.DOBDataGridViewTextBoxColumn.HeaderText = "DOB"
        Me.DOBDataGridViewTextBoxColumn.Name = "DOBDataGridViewTextBoxColumn"
        '
        'GENDERDataGridViewTextBoxColumn
        '
        Me.GENDERDataGridViewTextBoxColumn.DataPropertyName = "GENDER"
        Me.GENDERDataGridViewTextBoxColumn.HeaderText = "GENDER"
        Me.GENDERDataGridViewTextBoxColumn.Name = "GENDERDataGridViewTextBoxColumn"
        '
        'PLACEOFRESIDENCEDataGridViewTextBoxColumn
        '
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.DataPropertyName = "PLACE OF RESIDENCE"
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.HeaderText = "PLACE OF RESIDENCE"
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.Name = "PLACEOFRESIDENCEDataGridViewTextBoxColumn"
        '
        'ACADEMICQUALIFICATIONDataGridViewTextBoxColumn
        '
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.DataPropertyName = "ACADEMIC QUALIFICATION"
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.HeaderText = "ACADEMIC QUALIFICATION"
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.Name = "ACADEMICQUALIFICATIONDataGridViewTextBoxColumn"
        '
        'TELEPHONENUMBERDataGridViewTextBoxColumn
        '
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.DataPropertyName = "TELEPHONE NUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.HeaderText = "TELEPHONE NUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.Name = "TELEPHONENUMBERDataGridViewTextBoxColumn"
        '
        'EMAILDataGridViewTextBoxColumn
        '
        Me.EMAILDataGridViewTextBoxColumn.DataPropertyName = "E-MAIL"
        Me.EMAILDataGridViewTextBoxColumn.HeaderText = "E-MAIL"
        Me.EMAILDataGridViewTextBoxColumn.Name = "EMAILDataGridViewTextBoxColumn"
        '
        'MARITALSTATUSDataGridViewTextBoxColumn
        '
        Me.MARITALSTATUSDataGridViewTextBoxColumn.DataPropertyName = "MARITAL STATUS"
        Me.MARITALSTATUSDataGridViewTextBoxColumn.HeaderText = "MARITAL STATUS"
        Me.MARITALSTATUSDataGridViewTextBoxColumn.Name = "MARITALSTATUSDataGridViewTextBoxColumn"
        '
        'MEMBERINFOBindingSource
        '
        Me.MEMBERINFOBindingSource.DataMember = "MEMBER INFO"
        Me.MEMBERINFOBindingSource.DataSource = Me.CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        'CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.DataSetName = "CHURCH_MANAGEMENT_SYSTEMDataSet"
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MEMBER_INFOTableAdapter
        '
        Me.MEMBER_INFOTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button1.Location = New System.Drawing.Point(160, 278)
        Me.Button1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 32)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "SAVE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(473, 361)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Algerian", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form2"
        Me.Text = "ADD MEMEBR"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CHURCH_MANAGEMENT_SYSTEMDataSet As CHURCH_MANAGEMENT_SYSTEMDataSet
    Friend WithEvents MEMBERINFOBindingSource As BindingSource
    Friend WithEvents MEMBER_INFOTableAdapter As CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.MEMBER_INFOTableAdapter
    Friend WithEvents FIRSTNAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LASTNAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DOBDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GENDERDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PLACEOFRESIDENCEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ACADEMICQUALIFICATIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TELEPHONENUMBERDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EMAILDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MARITALSTATUSDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
