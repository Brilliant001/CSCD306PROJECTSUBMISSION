﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CHOIRDEPARTMENTDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WOMENMINISTRYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MENMINISTRYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.YOUTHMINISTRYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DRAMADEPARTMENTDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OTHERDEPARTMENTSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CHURCHGROUPSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet = New WindowsApplication1.CHURCH_MANAGEMENT_SYSTEMDataSet()
        Me.CHURCH_GROUPSTableAdapter = New WindowsApplication1.CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.CHURCH_GROUPSTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.MEMBERINFOBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet2 = New WindowsApplication1.CHURCH_MANAGEMENT_SYSTEMDataSet2()
        Me.MEMBER_INFOTableAdapter = New WindowsApplication1.CHURCH_MANAGEMENT_SYSTEMDataSet2TableAdapters.MEMBER_INFOTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHURCHGROUPSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CHOIRDEPARTMENTDataGridViewTextBoxColumn, Me.WOMENMINISTRYDataGridViewTextBoxColumn, Me.MENMINISTRYDataGridViewTextBoxColumn, Me.YOUTHMINISTRYDataGridViewTextBoxColumn, Me.DRAMADEPARTMENTDataGridViewTextBoxColumn, Me.SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn, Me.OTHERDEPARTMENTSDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.CHURCHGROUPSBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(30, 92)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(753, 240)
        Me.DataGridView1.TabIndex = 0
        '
        'CHOIRDEPARTMENTDataGridViewTextBoxColumn
        '
        Me.CHOIRDEPARTMENTDataGridViewTextBoxColumn.DataPropertyName = "CHOIR DEPARTMENT"
        Me.CHOIRDEPARTMENTDataGridViewTextBoxColumn.HeaderText = "CHOIR DEPARTMENT"
        Me.CHOIRDEPARTMENTDataGridViewTextBoxColumn.Name = "CHOIRDEPARTMENTDataGridViewTextBoxColumn"
        '
        'WOMENMINISTRYDataGridViewTextBoxColumn
        '
        Me.WOMENMINISTRYDataGridViewTextBoxColumn.DataPropertyName = "WOMEN MINISTRY"
        Me.WOMENMINISTRYDataGridViewTextBoxColumn.HeaderText = "WOMEN MINISTRY"
        Me.WOMENMINISTRYDataGridViewTextBoxColumn.Name = "WOMENMINISTRYDataGridViewTextBoxColumn"
        '
        'MENMINISTRYDataGridViewTextBoxColumn
        '
        Me.MENMINISTRYDataGridViewTextBoxColumn.DataPropertyName = "MEN MINISTRY"
        Me.MENMINISTRYDataGridViewTextBoxColumn.HeaderText = "MEN MINISTRY"
        Me.MENMINISTRYDataGridViewTextBoxColumn.Name = "MENMINISTRYDataGridViewTextBoxColumn"
        '
        'YOUTHMINISTRYDataGridViewTextBoxColumn
        '
        Me.YOUTHMINISTRYDataGridViewTextBoxColumn.DataPropertyName = "YOUTH MINISTRY"
        Me.YOUTHMINISTRYDataGridViewTextBoxColumn.HeaderText = "YOUTH MINISTRY"
        Me.YOUTHMINISTRYDataGridViewTextBoxColumn.Name = "YOUTHMINISTRYDataGridViewTextBoxColumn"
        '
        'DRAMADEPARTMENTDataGridViewTextBoxColumn
        '
        Me.DRAMADEPARTMENTDataGridViewTextBoxColumn.DataPropertyName = "DRAMA DEPARTMENT"
        Me.DRAMADEPARTMENTDataGridViewTextBoxColumn.HeaderText = "DRAMA DEPARTMENT"
        Me.DRAMADEPARTMENTDataGridViewTextBoxColumn.Name = "DRAMADEPARTMENTDataGridViewTextBoxColumn"
        '
        'SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn
        '
        Me.SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn.DataPropertyName = "SPOKEN WORD DEPARTMENT"
        Me.SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn.HeaderText = "SPOKEN WORD DEPARTMENT"
        Me.SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn.Name = "SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn"
        '
        'OTHERDEPARTMENTSDataGridViewTextBoxColumn
        '
        Me.OTHERDEPARTMENTSDataGridViewTextBoxColumn.DataPropertyName = "OTHER DEPARTMENTS"
        Me.OTHERDEPARTMENTSDataGridViewTextBoxColumn.HeaderText = "OTHER DEPARTMENTS"
        Me.OTHERDEPARTMENTSDataGridViewTextBoxColumn.Name = "OTHERDEPARTMENTSDataGridViewTextBoxColumn"
        '
        'CHURCHGROUPSBindingSource
        '
        Me.CHURCHGROUPSBindingSource.DataMember = "CHURCH GROUPS"
        Me.CHURCHGROUPSBindingSource.DataSource = Me.CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        'CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.DataSetName = "CHURCH_MANAGEMENT_SYSTEMDataSet"
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CHURCH_GROUPSTableAdapter
        '
        Me.CHURCH_GROUPSTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button1.Location = New System.Drawing.Point(168, 376)
        Me.Button1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(222, 28)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "SAVE CHANGES"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button2.Location = New System.Drawing.Point(462, 376)
        Me.Button2.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(125, 28)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "CANCEL"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(615, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "SEARCH"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.MEMBERINFOBindingSource
        Me.ComboBox1.DisplayMember = "LAST NAME"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(719, 6)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(130, 24)
        Me.ComboBox1.TabIndex = 4
        '
        'MEMBERINFOBindingSource
        '
        Me.MEMBERINFOBindingSource.DataMember = "MEMBER INFO"
        Me.MEMBERINFOBindingSource.DataSource = Me.CHURCH_MANAGEMENT_SYSTEMDataSet2
        '
        'CHURCH_MANAGEMENT_SYSTEMDataSet2
        '
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet2.DataSetName = "CHURCH_MANAGEMENT_SYSTEMDataSet2"
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MEMBER_INFOTableAdapter
        '
        Me.MEMBER_INFOTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(869, 431)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "CHURCH GROUPS"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHURCHGROUPSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CHURCH_MANAGEMENT_SYSTEMDataSet As CHURCH_MANAGEMENT_SYSTEMDataSet
    Friend WithEvents CHURCHGROUPSBindingSource As BindingSource
    Friend WithEvents CHURCH_GROUPSTableAdapter As CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.CHURCH_GROUPSTableAdapter
    Friend WithEvents CHOIRDEPARTMENTDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WOMENMINISTRYDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MENMINISTRYDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents YOUTHMINISTRYDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DRAMADEPARTMENTDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SPOKENWORDDEPARTMENTDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OTHERDEPARTMENTSDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents CHURCH_MANAGEMENT_SYSTEMDataSet2 As CHURCH_MANAGEMENT_SYSTEMDataSet2
    Friend WithEvents MEMBERINFOBindingSource As BindingSource
    Friend WithEvents MEMBER_INFOTableAdapter As CHURCH_MANAGEMENT_SYSTEMDataSet2TableAdapters.MEMBER_INFOTableAdapter
End Class
