﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.FIRSTNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LASTNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOBDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GENDERDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMAILDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MARITALSTATUSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PICTURE = New System.Windows.Forms.DataGridViewImageColumn()
        Me.MEMBERINFOBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet = New CSM_11.CHURCH_MANAGEMENT_SYSTEMDataSet()
        Me.MEMBER_INFOTableAdapter = New CSM_11.CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.MEMBER_INFOTableAdapter()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MEMBERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADDMEMBERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITMEMBERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ANNOUNCEMENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADDMEMBERTOGROUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITMEMBERToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CREATENEWGROUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONTRIBUTIONSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OFFERINGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TITHEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PARTNERSHIPSEEDSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DONATIONSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OTHERFUNDSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTENDANCEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MEDIAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADDMEDIAITEMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEMEDIAITEMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FIRSTNAMEDataGridViewTextBoxColumn, Me.LASTNAMEDataGridViewTextBoxColumn, Me.DOBDataGridViewTextBoxColumn, Me.GENDERDataGridViewTextBoxColumn, Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn, Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn, Me.TELEPHONENUMBERDataGridViewTextBoxColumn, Me.EMAILDataGridViewTextBoxColumn, Me.MARITALSTATUSDataGridViewTextBoxColumn, Me.PICTURE})
        Me.DataGridView1.DataSource = Me.MEMBERINFOBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(223, 70)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 65
        Me.DataGridView1.Size = New System.Drawing.Size(1052, 513)
        Me.DataGridView1.TabIndex = 2
        '
        'FIRSTNAMEDataGridViewTextBoxColumn
        '
        Me.FIRSTNAMEDataGridViewTextBoxColumn.DataPropertyName = "FIRST NAME]"
        Me.FIRSTNAMEDataGridViewTextBoxColumn.HeaderText = "FIRST NAME]"
        Me.FIRSTNAMEDataGridViewTextBoxColumn.Name = "FIRSTNAMEDataGridViewTextBoxColumn"
        '
        'LASTNAMEDataGridViewTextBoxColumn
        '
        Me.LASTNAMEDataGridViewTextBoxColumn.DataPropertyName = "LAST NAME"
        Me.LASTNAMEDataGridViewTextBoxColumn.HeaderText = "LAST NAME"
        Me.LASTNAMEDataGridViewTextBoxColumn.Name = "LASTNAMEDataGridViewTextBoxColumn"
        '
        'DOBDataGridViewTextBoxColumn
        '
        Me.DOBDataGridViewTextBoxColumn.DataPropertyName = "DOB"
        Me.DOBDataGridViewTextBoxColumn.HeaderText = "DOB"
        Me.DOBDataGridViewTextBoxColumn.Name = "DOBDataGridViewTextBoxColumn"
        Me.DOBDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'GENDERDataGridViewTextBoxColumn
        '
        Me.GENDERDataGridViewTextBoxColumn.DataPropertyName = "GENDER"
        Me.GENDERDataGridViewTextBoxColumn.HeaderText = "GENDER"
        Me.GENDERDataGridViewTextBoxColumn.Name = "GENDERDataGridViewTextBoxColumn"
        '
        'PLACEOFRESIDENCEDataGridViewTextBoxColumn
        '
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.DataPropertyName = "PLACE OF RESIDENCE"
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.HeaderText = "PLACE OF RESIDENCE"
        Me.PLACEOFRESIDENCEDataGridViewTextBoxColumn.Name = "PLACEOFRESIDENCEDataGridViewTextBoxColumn"
        '
        'ACADEMICQUALIFICATIONDataGridViewTextBoxColumn
        '
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.DataPropertyName = "ACADEMIC QUALIFICATION"
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.HeaderText = "ACADEMIC QUALIFICATION"
        Me.ACADEMICQUALIFICATIONDataGridViewTextBoxColumn.Name = "ACADEMICQUALIFICATIONDataGridViewTextBoxColumn"
        '
        'TELEPHONENUMBERDataGridViewTextBoxColumn
        '
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.DataPropertyName = "TELEPHONE NUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.HeaderText = "TELEPHONE NUMBER"
        Me.TELEPHONENUMBERDataGridViewTextBoxColumn.Name = "TELEPHONENUMBERDataGridViewTextBoxColumn"
        '
        'EMAILDataGridViewTextBoxColumn
        '
        Me.EMAILDataGridViewTextBoxColumn.DataPropertyName = "E-MAIL"
        Me.EMAILDataGridViewTextBoxColumn.HeaderText = "E-MAIL"
        Me.EMAILDataGridViewTextBoxColumn.Name = "EMAILDataGridViewTextBoxColumn"
        Me.EMAILDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'MARITALSTATUSDataGridViewTextBoxColumn
        '
        Me.MARITALSTATUSDataGridViewTextBoxColumn.DataPropertyName = "MARITAL STATUS"
        Me.MARITALSTATUSDataGridViewTextBoxColumn.HeaderText = "MARITAL STATUS"
        Me.MARITALSTATUSDataGridViewTextBoxColumn.Name = "MARITALSTATUSDataGridViewTextBoxColumn"
        Me.MARITALSTATUSDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'PICTURE
        '
        Me.PICTURE.DataPropertyName = "FIRST NAME]"
        Me.PICTURE.HeaderText = "PROFILE PICTURE"
        Me.PICTURE.Image = Global.CSM_11.My.Resources.Resources.ADD_P
        Me.PICTURE.Name = "PICTURE"
        Me.PICTURE.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PICTURE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'MEMBERINFOBindingSource
        '
        Me.MEMBERINFOBindingSource.DataMember = "MEMBER INFO"
        Me.MEMBERINFOBindingSource.DataSource = Me.CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        'CHURCH_MANAGEMENT_SYSTEMDataSet
        '
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.DataSetName = "CHURCH_MANAGEMENT_SYSTEMDataSet"
        Me.CHURCH_MANAGEMENT_SYSTEMDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MEMBER_INFOTableAdapter
        '
        Me.MEMBER_INFOTableAdapter.ClearBeforeFill = True
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.CheckedListBox1.Font = New System.Drawing.Font("Algerian", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"ADD NEW  MEMBER", "EDIT MEMBER", "SEND A MEMBER AN E-MAIL", "CHECK ATTENDANCE", "CHURCH CONTRIBUTIONS", "GROUPS", "CHURCH ACTIVITIES", "ANNOUNCEMENTS"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(0, 70)
        Me.CheckedListBox1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(221, 220)
        Me.CheckedListBox1.TabIndex = 3
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button3.Location = New System.Drawing.Point(360, 663)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(144, 29)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "SAVE CHANGES"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button4.Location = New System.Drawing.Point(601, 663)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 29)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "DELETE"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(870, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 18)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "SEARCH BOX"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.MEMBERINFOBindingSource
        Me.ComboBox1.DisplayMember = "FIRST NAME]"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(1025, 4)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(238, 26)
        Me.ComboBox1.TabIndex = 7
        Me.ComboBox1.ValueMember = "LAST NAME"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MEMBERToolStripMenuItem, Me.ANNOUNCEMENTToolStripMenuItem, Me.GROUPToolStripMenuItem, Me.CONTRIBUTIONSToolStripMenuItem, Me.ATTENDANCEToolStripMenuItem, Me.MEDIAToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1275, 26)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MEMBERToolStripMenuItem
        '
        Me.MEMBERToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADDMEMBERToolStripMenuItem, Me.EDITMEMBERToolStripMenuItem})
        Me.MEMBERToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MEMBERToolStripMenuItem.Name = "MEMBERToolStripMenuItem"
        Me.MEMBERToolStripMenuItem.Size = New System.Drawing.Size(97, 22)
        Me.MEMBERToolStripMenuItem.Text = "MEMBER"
        '
        'ADDMEMBERToolStripMenuItem
        '
        Me.ADDMEMBERToolStripMenuItem.Name = "ADDMEMBERToolStripMenuItem"
        Me.ADDMEMBERToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.ADDMEMBERToolStripMenuItem.Text = "ADD MEMBER"
        '
        'EDITMEMBERToolStripMenuItem
        '
        Me.EDITMEMBERToolStripMenuItem.Name = "EDITMEMBERToolStripMenuItem"
        Me.EDITMEMBERToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.EDITMEMBERToolStripMenuItem.Text = "EDIT MEMBER"
        '
        'ANNOUNCEMENTToolStripMenuItem
        '
        Me.ANNOUNCEMENTToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ANNOUNCEMENTToolStripMenuItem.Name = "ANNOUNCEMENTToolStripMenuItem"
        Me.ANNOUNCEMENTToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ANNOUNCEMENTToolStripMenuItem.Text = "ANNOUNCEMENT"
        '
        'GROUPToolStripMenuItem
        '
        Me.GROUPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADDMEMBERTOGROUPToolStripMenuItem, Me.EDITMEMBERToolStripMenuItem1, Me.CREATENEWGROUPToolStripMenuItem})
        Me.GROUPToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GROUPToolStripMenuItem.Name = "GROUPToolStripMenuItem"
        Me.GROUPToolStripMenuItem.Size = New System.Drawing.Size(90, 22)
        Me.GROUPToolStripMenuItem.Text = "GROUPS"
        '
        'ADDMEMBERTOGROUPToolStripMenuItem
        '
        Me.ADDMEMBERTOGROUPToolStripMenuItem.Name = "ADDMEMBERTOGROUPToolStripMenuItem"
        Me.ADDMEMBERTOGROUPToolStripMenuItem.Size = New System.Drawing.Size(288, 22)
        Me.ADDMEMBERTOGROUPToolStripMenuItem.Text = "ADD MEMBER TO GROUP"
        '
        'EDITMEMBERToolStripMenuItem1
        '
        Me.EDITMEMBERToolStripMenuItem1.Name = "EDITMEMBERToolStripMenuItem1"
        Me.EDITMEMBERToolStripMenuItem1.Size = New System.Drawing.Size(288, 22)
        Me.EDITMEMBERToolStripMenuItem1.Text = "EDIT MEMBER"
        '
        'CREATENEWGROUPToolStripMenuItem
        '
        Me.CREATENEWGROUPToolStripMenuItem.Name = "CREATENEWGROUPToolStripMenuItem"
        Me.CREATENEWGROUPToolStripMenuItem.Size = New System.Drawing.Size(288, 22)
        Me.CREATENEWGROUPToolStripMenuItem.Text = "CREATE NEW GROUP"
        '
        'CONTRIBUTIONSToolStripMenuItem
        '
        Me.CONTRIBUTIONSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OFFERINGToolStripMenuItem, Me.TITHEToolStripMenuItem, Me.PARTNERSHIPSEEDSToolStripMenuItem, Me.DONATIONSToolStripMenuItem, Me.OTHERFUNDSToolStripMenuItem})
        Me.CONTRIBUTIONSToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CONTRIBUTIONSToolStripMenuItem.Name = "CONTRIBUTIONSToolStripMenuItem"
        Me.CONTRIBUTIONSToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.CONTRIBUTIONSToolStripMenuItem.Text = "CONTRIBUTIONS"
        '
        'OFFERINGToolStripMenuItem
        '
        Me.OFFERINGToolStripMenuItem.Name = "OFFERINGToolStripMenuItem"
        Me.OFFERINGToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.OFFERINGToolStripMenuItem.Text = "OFFERING"
        '
        'TITHEToolStripMenuItem
        '
        Me.TITHEToolStripMenuItem.Name = "TITHEToolStripMenuItem"
        Me.TITHEToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.TITHEToolStripMenuItem.Text = "TITHE"
        '
        'PARTNERSHIPSEEDSToolStripMenuItem
        '
        Me.PARTNERSHIPSEEDSToolStripMenuItem.Name = "PARTNERSHIPSEEDSToolStripMenuItem"
        Me.PARTNERSHIPSEEDSToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.PARTNERSHIPSEEDSToolStripMenuItem.Text = "PARTNERSHIP SEEDS"
        '
        'DONATIONSToolStripMenuItem
        '
        Me.DONATIONSToolStripMenuItem.Name = "DONATIONSToolStripMenuItem"
        Me.DONATIONSToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.DONATIONSToolStripMenuItem.Text = "DONATIONS"
        '
        'OTHERFUNDSToolStripMenuItem
        '
        Me.OTHERFUNDSToolStripMenuItem.Name = "OTHERFUNDSToolStripMenuItem"
        Me.OTHERFUNDSToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.OTHERFUNDSToolStripMenuItem.Text = "OTHER FUNDS"
        '
        'ATTENDANCEToolStripMenuItem
        '
        Me.ATTENDANCEToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ATTENDANCEToolStripMenuItem.Name = "ATTENDANCEToolStripMenuItem"
        Me.ATTENDANCEToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.ATTENDANCEToolStripMenuItem.Text = "ATTENDANCE"
        '
        'MEDIAToolStripMenuItem
        '
        Me.MEDIAToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADDMEDIAITEMToolStripMenuItem, Me.DELETEMEDIAITEMToolStripMenuItem})
        Me.MEDIAToolStripMenuItem.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MEDIAToolStripMenuItem.Name = "MEDIAToolStripMenuItem"
        Me.MEDIAToolStripMenuItem.Size = New System.Drawing.Size(77, 22)
        Me.MEDIAToolStripMenuItem.Text = "MEDIA"
        '
        'ADDMEDIAITEMToolStripMenuItem
        '
        Me.ADDMEDIAITEMToolStripMenuItem.Name = "ADDMEDIAITEMToolStripMenuItem"
        Me.ADDMEDIAITEMToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ADDMEDIAITEMToolStripMenuItem.Text = "ADD MEDIA ITEM"
        '
        'DELETEMEDIAITEMToolStripMenuItem
        '
        Me.DELETEMEDIAITEMToolStripMenuItem.Name = "DELETEMEDIAITEMToolStripMenuItem"
        Me.DELETEMEDIAITEMToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.DELETEMEDIAITEMToolStripMenuItem.Text = "DELETE MEDIA ITEM"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CSM_11.My.Resources.Resources._12341
        Me.ClientSize = New System.Drawing.Size(1275, 720)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Algerian", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.ShowIcon = False
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHURCH_MANAGEMENT_SYSTEMDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CHURCH_MANAGEMENT_SYSTEMDataSet As CHURCH_MANAGEMENT_SYSTEMDataSet
    Friend WithEvents MEMBER_INFOTableAdapter As CHURCH_MANAGEMENT_SYSTEMDataSetTableAdapters.MEMBER_INFOTableAdapter
    Friend WithEvents MEMBERINFOBindingSource As BindingSource
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents FIRSTNAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LASTNAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DOBDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GENDERDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PLACEOFRESIDENCEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ACADEMICQUALIFICATIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TELEPHONENUMBERDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EMAILDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MARITALSTATUSDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PICTURE As DataGridViewImageColumn
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MEMBERToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADDMEMBERToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EDITMEMBERToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ANNOUNCEMENTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GROUPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADDMEMBERTOGROUPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EDITMEMBERToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CREATENEWGROUPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CONTRIBUTIONSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OFFERINGToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TITHEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PARTNERSHIPSEEDSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DONATIONSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OTHERFUNDSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ATTENDANCEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MEDIAToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADDMEDIAITEMToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DELETEMEDIAITEMToolStripMenuItem As ToolStripMenuItem
End Class
